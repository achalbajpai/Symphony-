const { Message, Client, MessageEmbed } = require("discord.js");
const { pagination } = require('reconlx');
module.exports = {
    name: "help",
    aliases: ['cmds'],
    permissions : [""],
    description: "",
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {

      const ch = message.channel;
      if(!ch.permissionsFor(message.guild.me).has("EMBED_LINKS")) {
        message.reply({content: 'I do not have `EMBED_LINKS` Permission for this channel.'})
        return;
      }


      const embed = new MessageEmbed()
      .setTitle("Symphony Help")
      .setDescription(` My prefix for commands is \`s!\` \nAdvanced Music Bot with 40+ Custom Filters, Custom Playlist Support & Slash Commands As well! `)
      .setColor('#3498db')
      .setImage('https://media.discordapp.net/attachments/862016314046152794/908457532182376500/standard.gif')
      .setFooter('To see all of the bot commands use the buttons below!');

      const second = new MessageEmbed()
      .setTitle('Music Commands')
      .setColor('#3498db')
      .setDescription(`
      <:rightarrow:890682857322856448> Play <query> - \`Play Music From Spotify or Youtube\`\n
      <:rightarrow:890682857322856448> Pause - \`Pause the music\`\n
      <:rightarrow:890682857322856448> Resume - \`Resmume the paused music!\`\n
      <:rightarrow:890682857322856448> Skip - \`Skip to next music in queue\`\n
      <:rightarrow:890682857322856448> Stop - \`Stop Music Playback\`\n
      `)
      .setFooter('To see all of the bot commands use the buttons below!');

      const third = new MessageEmbed()
      .setTitle('Music Commands')
      .setColor('#3498db')
      .setDescription(`
      <:rightarrow:890682857322856448> Nowplaying - \`Shows info about the music being played right now\`\n
      <:rightarrow:890682857322856448> Queue - \`Lists the upcoming songs in queue.\`\n
      <:rightarrow:890682857322856448> Shuffle - \`Shuffles the music\`\n
      <:rightarrow:890682857322856448> Loop Song/Queue/Off - \`Enable/Disable the loop of song or whole queue\`\n
      <:rightarrow:890682857322856448> Volume <volume> - \`Adjust the volume of music.\`\n
      `)
      .setFooter('To see all of the bot commands use the buttons below!');

      let customEmbed = new MessageEmbed()
     .setTitle('Custom Playlist Help')
     .setColor('#3498db')
     .setDescription(`
     <:rightarrow:890682857322856448> Custom add <url> - \`Add music to your custom playlist!\`\n
     <:rightarrow:890682857322856448> Custom play - \`Play/Add your custom queue to music playback!\`\n
     <:rightarrow:890682857322856448> Custom reset - \`Resets and clears your custom playlist!\`\n
     `)
     .setFooter('To see all of the bot commands use the buttons below!');

      const fourth = new MessageEmbed()
      .setTitle('Other Commands')
      .setColor('#3498db')
      .setDescription(`
            <:rightarrow:890682857322856448> Invite - \`Shows the invite link of bot\`\n
            <:rightarrow:890682857322856448> Support - \`Shows the support server link of bot\`\n
            <:rightarrow:890682857322856448> Stats - \`Shows the bot stats for nerds!\`\n
      `)
       .setFooter('To see all of the bot commands use the buttons below!');

       const fifth = new MessageEmbed()
        .setTitle('Music Filters')
        .setColor('#3498db')
        .setDescription(`Available Filters: \`clear, bassboost, 8D, vaporwave, nightcore, phaser, tremolo, vibrato, reverse, treble, normalizer, surrounding, pulsator, subboost, karaoke, flanger, gate, haas, mcompand, double, half, cursed, rickroll, purebass, 3D, earwax, mono, echo, sofalizer, aphaser, apulsator, asetrate, speed, superspeed, slow, superslow, deesser, earrape, lightbass, heavybass\``)
        .setFooter('To see all of the bot commands use the buttons below!');
       const embedss = [embed, second, third, customEmbed, fifth, fourth];

       pagination({
         embeds: embedss,
         channel: message.channel,
         author: message.author,
         message: message,
         time: 200000,
         fastSkip: false,
         pageTravel: false,
       })
    },
};